//
//  NextSevenDaysViewController.swift
//  WeatherApp
//
//  Created by Mac on 10/10/24.
//

import UIKit

class NextSevenDaysViewController: UIViewController {
    @IBOutlet weak var NextSevenDaysCollectionView: UICollectionView!
    var weatherData: [WeatherData] = []
    
    override func viewDidLoad() {
        super.viewDidLoad()
        NextSevenDaysCollectionView.delegate = self
        NextSevenDaysCollectionView.dataSource = self
        fetchWeatherData()
    }
    
    @IBAction func backBtn(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    func fetchWeatherData() {
        let apiURLString = "https://api.openweathermap.org/data/2.5/forecast?q=Mumbai&appid=79f4dee6de7a4f6dc54b69d870c20f8e"
        
        ServiceManager.shared.getDataFromAPI(urlString: apiURLString) { [weak self] (result: Result<WeatherResponse, Error>) in
            switch result {
            case .success(let weatherResponse):
                self?.weatherData = weatherResponse.list
                
                DispatchQueue.main.async {
                    self?.NextSevenDaysCollectionView.reloadData()
                }
            case .failure(let error):
                print("Failed to fetch weather data: \(error)")
            }
        }
    }
}

extension NextSevenDaysViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return weatherData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "NextSevenDaysCollectionViewCell", for: indexPath) as! NextSevenDaysCollectionViewCell
        cell.layer.cornerRadius = 12
        cell.layer.masksToBounds = true
        let data = weatherData[indexPath.row]
        cell.configure(with: data)
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.size.width
        return CGSize(width: width/4 - 20, height: width/4 - 20)
    }
}



