//
//  WeatherAppViewController.swift
//  WeatherApp
//
//  Created by Mac on 10/10/24.
//

import UIKit

class WeatherAppViewController: UIViewController {
    
    var weatherData: [WeatherData] = []
    var currentSelected : Int?
    @IBOutlet weak var cityName: UILabel!
    @IBOutlet weak var weatherName: UILabel!
    @IBOutlet weak var tempreture: UILabel!
    @IBOutlet weak var uvLabel: UILabel!
    @IBOutlet weak var pressure: UILabel!
    @IBOutlet weak var feelslike: UILabel!
    @IBOutlet weak var datelbl: UILabel!
    @IBOutlet weak var countryName: UILabel!
    @IBOutlet weak var WeatherImage: UIImageView!
    @IBOutlet weak var WeatherAppCollectionView: UICollectionView!
    @IBOutlet weak var WeatherView: UIView!
    @IBOutlet weak var windView: UIView!
    @IBOutlet weak var feelsLikeView: UIView!
    @IBOutlet weak var uvIndexView: UIView!
    @IBOutlet weak var presureView: UIView!
    @IBOutlet weak var wind: UILabel!
    
    var timeArray = ["12:00","14:00","16:00","18:00","20:00","22:00","00:00","02:00","04:00","06:00","08:00"]
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        WeatherAppCollectionView.delegate = self
        WeatherAppCollectionView.dataSource = self
        fetchWeatherData()
        WeatherView.layer.cornerRadius = 14
        setBorderView()
        callPostApi()
        
    }
    func setBorderView() {
        windView.setBorderToView()
        feelsLikeView.setBorderToView()
        uvIndexView.setBorderToView()
        presureView.setBorderToView()
    }
    
    func callPostApi() {
        let requestModel = PostRequest(title: "Foo", body: "Bar", userId: 1)
        let apiURLString = "https://jsonplaceholder.typicode.com/posts"
        
        ServiceManager.shared.postData(urlString: apiURLString, parameters: requestModel) { (result: Result<PostResponse, Error>) in
            switch result {
            case .success(let response):
                print("Post created with ID: \(response.id)")
            case .failure(let error):
                print("Error: \(error.localizedDescription)")
            }
        }
    }
    
    func fetchWeatherData() {
        let apiURLString = "https://api.openweathermap.org/data/2.5/forecast?q=Mumbai&appid=79f4dee6de7a4f6dc54b69d870c20f8e"
        
        ServiceManager.shared.getDataFromAPI(urlString: apiURLString) { [weak self] (result: Result<WeatherResponse, Error>) in
            switch result {
            case .success(let weatherResponse):
                self?.weatherData = weatherResponse.list
                
                DispatchQueue.main.async {
                    self?.WeatherAppCollectionView.reloadData()
                    self?.cityName.text = weatherResponse.city.name
                    if let firstWeather = self?.weatherData.first {
                        self?.wind.text = "Speed \(firstWeather.wind.speed) km"
                        self?.pressure.text = "\(firstWeather.main.pressure)"
                        self?.uvLabel.text = "\(firstWeather.main.humidity)"
                        self?.feelslike.text = "\(firstWeather.main.feelsLike)"
                        self?.weatherName.text = firstWeather.weather.first?.description ?? "N/A"
                    }
                }
            case .failure(let error):
                print("Failed to fetch weather data: \(error)")
            }
        }
    }
    @IBAction func nextSevenDaysutton(_ sender: Any) {
        let mainS = UIStoryboard(name: "Main", bundle: nil)
        let vc = mainS.instantiateViewController(withIdentifier: "NextSevenDaysViewController") as! NextSevenDaysViewController
        self.navigationController?.pushViewController(vc, animated:true)
    }
}


extension WeatherAppViewController: UICollectionViewDelegate, UICollectionViewDataSource, UICollectionViewDelegateFlowLayout {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return weatherData.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "WeatherAppCollectionViewCell", for: indexPath) as! WeatherAppCollectionViewCell
        
        
        if currentSelected != nil && currentSelected == indexPath.row
        {
            cell.forecastView.backgroundColor = UIColor.systemBlue
            
        }else{
            cell.forecastView.backgroundColor = UIColor.white
        }
        
        let data = weatherData[indexPath.item]
        cell.forecastView.layer.cornerRadius = 12
        cell.forecastView.layer.masksToBounds = true
        cell.forecastView.layer.borderColor = UIColor.lightGray.cgColor
        cell.forecastView.layer.borderWidth = 0.5
        cell.timelbl.text = timeArray[indexPath.row]
        cell.configure(with: data)
        return cell
        
    }
    
    func collectionView(_ collectionView: UICollectionView, layout collectionViewLayout: UICollectionViewLayout, sizeForItemAt indexPath: IndexPath) -> CGSize {
        let width = collectionView.frame.size.width
        return CGSize(width: width/4 - 20, height: width/3 + 40)
    }
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        currentSelected = indexPath.row
        self.WeatherAppCollectionView.reloadItems(at: [indexPath])
    }
}

