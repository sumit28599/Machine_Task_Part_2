//
//  NextSevenDaysCollectionViewCell.swift
//  WeatherApp
//
//  Created by Mac on 10/10/24.
//

import UIKit

class NextSevenDaysCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var weatherImg: UIImageView!
    @IBOutlet weak var daysAndDate: UILabel!
    @IBOutlet weak var tempreture: UILabel!
    
    func configure(with data: WeatherData) {
        let celsiusTemp = (data.main.temp - 273.15)
        let temperature = String(format: "%.1f", celsiusTemp)
        daysAndDate.text = "temperature: \(temperature)°C"
    }
}
