//
//  WeatherAppCollectionViewCell.swift
//  WeatherApp
//
//  Created by Mac on 10/10/24.
//

import UIKit

class WeatherAppCollectionViewCell: UICollectionViewCell {
    @IBOutlet weak var forecastView: UIView!
    @IBOutlet weak var weatherImg: UIImageView!
    @IBOutlet weak var timelbl: UILabel!
    @IBOutlet weak var tempreture: UILabel!
    
    func configure(with data: WeatherData) {
        let celsiusTemp = (data.main.temp - 273.15)
        let temperature = String(format: "%.1f", celsiusTemp)
        tempreture.text = "\(temperature)°C"
    }
}
