//
//  ServiceManager.swift
//  WeatherApp
//
//  Created by Mac on 10/10/24.
//

import Foundation
class ServiceManager {
    static let shared = ServiceManager()
    private init() {}

     func postData<T: Encodable, U: Decodable>(urlString: String, parameters: T, completion: @escaping (Result<U, Error>) -> Void) {
         guard let url = URL(string: urlString) else {
             completion(.failure(NSError(domain: "Invalid URL", code: -1, userInfo: nil)))
             return
         }

         var request = URLRequest(url: url)
         request.httpMethod = "POST"
         request.setValue("application/json", forHTTPHeaderField: "Content-Type")

         do {
             let jsonData = try JSONEncoder().encode(parameters)
             request.httpBody = jsonData
         } catch {
             completion(.failure(error))
             return
         }

         let task = URLSession.shared.dataTask(with: request) { data, response, error in
             if let error = error {
                 completion(.failure(error))
                 return
             }

             guard let data = data else {
                 completion(.failure(NSError(domain: "No data returned", code: -1, userInfo: nil)))
                 return
             }

             do {
                 let decodedResponse = try JSONDecoder().decode(U.self, from: data)
                 completion(.success(decodedResponse))
             } catch {
                 completion(.failure(error))
             }
         }

         task.resume()
     }
    func getDataFromAPI<T: Decodable>(urlString: String, completion: @escaping (Result<T, Error>) -> Void) {
        guard let url = URL(string: urlString) else {
            print("Failed to create URL!")
            return
        }
        
        let request = URLRequest(url: url)
        
        let task = URLSession.shared.dataTask(with: request) { data, response, error in
            if let error = error {
                print("Error fetching data: \(error)")
                completion(.failure(error))
                return
            }
            
            guard let data = data else {
                let error = NSError(domain: "", code: -1, userInfo: [NSLocalizedDescriptionKey: "No data returned"])
                completion(.failure(error))
                return
            }
            
            do {
                let decodedResponse = try JSONDecoder().decode(T.self, from: data)
                completion(.success(decodedResponse))
            } catch {
                print("Error decoding JSON: \(error)")
                completion(.failure(error))
            }
        }
        
        task.resume()
    }
    
}
