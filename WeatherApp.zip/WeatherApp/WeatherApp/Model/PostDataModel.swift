//
//  PostDataModel.swift
//  WeatherApp
//
//  Created by Mac on 10/10/24.
//

import Foundation
struct PostRequest: Encodable {
    let title: String
    let body: String
    let userId: Int
}

struct PostResponse: Decodable {
    let id: Int
    let title: String
    let body: String
    let userId: Int
}
