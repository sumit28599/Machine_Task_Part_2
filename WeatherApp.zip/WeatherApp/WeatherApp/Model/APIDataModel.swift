//
//  APIDataModel.swift
//  WeatherApp
//
//  Created by Mac on 10/10/24.
//


import Foundation

struct WeatherResponse: Codable {
    let list: [WeatherData]
    let city: City
}

struct WeatherData: Codable {
    let dt: TimeInterval
    let main: Main
    let weather: [Weather]
    let wind: Wind
}

struct Main: Codable {
    let temp: Double
    let feelsLike: Double
    let pressure: Int
    let humidity: Int
    enum CodingKeys: String, CodingKey {
            case temp
            case feelsLike = "feels_like"
            case pressure
            case humidity
           
        }
}

struct Weather: Codable {
    let description: String
    let icon: String
    enum Description: String, Codable {
        case brokenClouds = "broken clouds"
        case clearSky = "clear sky"
        case fewClouds = "few clouds"
        case lightRain = "light rain"
        case moderateRain = "moderate rain"
        case overcastClouds = "overcast clouds"
    }
}

struct City: Codable {
    let name: String
    let country: String
}
struct Wind: Codable {
    let speed: Double
    let deg: Int
    let gust: Double
}
