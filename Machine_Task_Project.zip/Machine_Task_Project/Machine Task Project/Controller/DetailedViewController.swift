//
//  DetailedViewController.swift
//  Machine Task Project
//
//  Created by Mac on 23/09/24.
//

import UIKit

class DetailedViewController: UIViewController {

    @IBOutlet weak var mainView: UIView!
    @IBOutlet weak var productImageView: UIImageView!
    @IBOutlet weak var nameLabel: UILabel!
    @IBOutlet weak var descriptionLabel: UILabel!
    @IBOutlet weak var priceLabel: UILabel!
    @IBOutlet weak var ratingLabel: UILabel!
    @IBOutlet weak var categoryLabel: UILabel!
    
    var name = ""
    var descname = ""
    var category = ""
    var price = ""
    var imageurl = ""
    var rating = ""
    override func viewDidLoad() {
        super.viewDidLoad()

        mainView.makeViewCircular()
        APIData ()
    }
    

    func APIData () {
        nameLabel.text = "Name: \(name)"
        descriptionLabel.text = "Description: \(descname)"
        ratingLabel.text = "Rating: \(rating)"
        priceLabel.text = "Price: \(price)"
        categoryLabel.text = "Category: \(category)"
        if let imageView = productImageView {
            let imageUrl = imageurl
            imageView.loadImage(from: imageUrl) // Call the loadImage function
        }
    }
    
    @IBAction func backBtnClick(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
    
}


