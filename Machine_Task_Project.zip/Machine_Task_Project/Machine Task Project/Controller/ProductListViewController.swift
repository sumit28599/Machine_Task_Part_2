//
//  ProductListViewController.swift
//  Machine Task Project
//
//  Created by Mac on 23/09/24.
//

import UIKit
import Foundation



class ProductListViewController: UIViewController {
    
    // MARK: - Outlets
    @IBOutlet weak var productTableView: UITableView!
    // MARK: - Variables
    var productDataArray: [ProductsDetails] = []

    override func viewDidLoad() {
        super.viewDidLoad()
        productTableView.delegate = self
        productTableView.dataSource = self
        productTableView.register(UINib(nibName: "ProductCell", bundle: nil), forCellReuseIdentifier: "ProductCell")
        if let userDataFromString = parseJson(from: Appconstants.jsonString) {
            let users = userDataFromString.items
            for user in users {
                productDataArray = convertUsersToUserData(users: users)
                print("userDataArray \(productDataArray)")
            }
        } else {
            print("Failed to parse JSON string.")
        }
    }

    func convertUsersToUserData(users: [Products]) -> [ProductsDetails] {
        return users.map { ProductsDetails(id: $0.id, name: $0.name, description: $0.description, price: $0.price, rating: $0.rating, category: $0.category, imageUrl: $0.image_url) }
    }

    func parseJson(from jsonString: String) -> ProductsData? {
        guard let data = jsonString.data(using: .utf8) else {
            print("Invalid JSON string.")
            return nil
        }
        
        do {
            let decoder = JSONDecoder()
            let userData = try decoder.decode(ProductsData.self, from: data)
            return userData
        } catch {
            print("Error decoding JSON: \(error)")
            return nil
        }
    }

    
    
    @IBAction func backBtnClick(_ sender: Any) {
        self.navigationController?.popViewController(animated: true)
    }
}

   

extension ProductListViewController: UITableViewDataSource, UITableViewDelegate {
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
       return productDataArray.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        guard let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell") as? ProductCell else {
            return UITableViewCell()
        }
        let productDataArray = productDataArray[indexPath.row]
        cell.product = productDataArray
        return cell
    }
    
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        
        let cell = tableView.dequeueReusableCell(withIdentifier: "ProductCell", for: indexPath) as! ProductCell
        let storyboard = UIStoryboard(name: "Main", bundle: nil)
        let vc = storyboard.instantiateViewController(withIdentifier: "DetailedViewController") as! DetailedViewController
        let product = productDataArray[indexPath.item]
               
        vc.name = product.name
        vc.category = product.category
        vc.price = "\(product.price)"
        vc.rating = "\(product.rating)"
        vc.descname = product.description
        vc.imageurl = product.imageUrl
        self.navigationController?.pushViewController(vc, animated: true)
        
    }
    
}
