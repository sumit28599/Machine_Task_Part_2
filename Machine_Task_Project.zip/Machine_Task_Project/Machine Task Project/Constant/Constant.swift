//
//  Constant.swift
//  Machine Task Project
//
//  Created by Mac on 23/09/24.
//

import Foundation

enum Constant {
    enum API {
        static let baseMovieURL = "https://simplifiedcoding.net/demos/marvel"
    }
}

let userStandard = UserDefaults.standard

enum UserDefaultKey: String {

    case isAlreadyLogin = "isAlreadyLogin"
    case userId = "userId"
    case userName = "userName"
    case registerUserCount = "registerUserCount"

}

struct Appconstants {
    static let jsonString = """
    {
        "items": [
            {
             "id": 101,
             "name": "MacBook Pro 16",
             "description": "A high-performance laptop for professionals with an M1 chip.",
             "price": 2499.99,
             "rating": 4.8,
             "category": "Electronics",
             "image_url": "https://farm6.staticflickr.com/5590/14821526429_5c6ea60405_z_d.jpg"
             },
             {
             "id": 102,
             "name": "Nike Air Max 270",
             "description": "Comfortable and stylish running shoes for daily wear.",
             "price": 149.99,
             "rating": 4.5,
             "category": "Footwear",
             "image_url": "https://farm7.staticflickr.com/6089/6115759179_86316c08ff_z_d.jpg"
             },
             {
             "id": 103,
             "name": "Sony WH-1000XM4",
             "description": "Industry-leading noise canceling wireless headphones.",
             "price": 349.99,
             "rating": 4.7,
             "category": "Accessories",
             "image_url": "https://farm2.staticflickr.com/1090/4595137268_0e3f2b9aa7_z_d.jpg"
             },
             {
             "id": 104,
             "name": "Samsung Galaxy S22",
             "description": "Next-generation smartphone with an advanced camera and display.",
             "price": 799.99,
             "rating": 4.6,
             "category": "Smartphones",
             "image_url": "https://farm4.staticflickr.com/3224/3081748027_0ee3d59fea_z_d.jpg"
             },
             {
             "id": 105,
             "name": "Instant Pot Duo",
             "description": "7-in-1 electric pressure cooker that speeds up cooking by 2-6 times.",
             "price": 89.99,
             "rating": 4.9,
             "category": "Home Appliances",
             "image_url": "https://farm8.staticflickr.com/7377/9359257263_81b080a039_z_d.jpg"
             }
        ]
    }
    """
}
