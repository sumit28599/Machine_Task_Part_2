//
//  UIImageView + Extension.swift
//  Machine Task Project
//
//  Created by apple on 28/09/23.
//

import UIKit

extension UIImageView {
    func loadImage(from urlString: String) {
        guard let url = URL(string: urlString) else { return }
        
        // Show a placeholder image while loading
        self.image = nil
        
        URLSession.shared.dataTask(with: url) { data, response, error in
            // Check for errors
            if let error = error {
                print("Error downloading image: \(error)")
                return
            }
            
            // Check for valid data
            guard let data = data, let image = UIImage(data: data) else {
                print("Could not convert data to image.")
                return
            }
            
            // Update the UIImageView on the main thread
            DispatchQueue.main.async {
                self.image = image
                self.setNeedsLayout() // Request layout update for the cell
            }
        }.resume() // Start the data task
    }
}
@IBDesignable class GradientBackgroundView: UIView {
    // implement cgcolorgradient in the next section
    @IBInspectable var startColor: UIColor? {
        didSet { gradientLayer.colors = cgColorGradient }
    }

    @IBInspectable var endColor: UIColor? {
        didSet { gradientLayer.colors = cgColorGradient }
    }

    @IBInspectable var startPoint: CGPoint = CGPoint(x: 0.0, y: 0.0) {
        didSet { gradientLayer.startPoint = startPoint }
    }

    @IBInspectable var endPoint: CGPoint = CGPoint(x: 1.0, y: 1.0) {
        didSet { gradientLayer.endPoint = endPoint }
    }

        // Enables more convenient access to layer
        var gradientLayer: CAGradientLayer {
            return layer as! CAGradientLayer
        }
        override open class var layerClass: AnyClass {
            return CAGradientLayer.classForCoder()
        }
}

extension GradientBackgroundView {
    internal var cgColorGradient: [CGColor]? {
        guard let startColor = startColor, let endColor = endColor else {
            return nil
        }
        
        return [startColor.cgColor, endColor.cgColor]
    }
}


extension UIView{
    
    func makeViewCircular(){
        self.layer.cornerRadius = self.frame.height/2
        self.layer.masksToBounds = true
    }
}
