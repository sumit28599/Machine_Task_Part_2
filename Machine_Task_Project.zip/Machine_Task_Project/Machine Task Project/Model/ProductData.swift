//
//  ProductData.swift
//  Machine Task Project
//
//  Created by Mac on 23/09/24.
//

import Foundation

struct Products: Codable {
    let id: Int
    let name: String
    let description: String
    let price: Double
    let rating: Double
    let category: String
    let image_url: String
    
//    enum CodingKeys: String, CodingKey {
//        case id
//        case name
//        case description
//        case price
//        case rating
//        case category
//        case imageUrl = "image_url"
//    }
}

struct ProductsData: Codable {
    let items: [Products]
}
struct ProductsDetails: Codable {
    let id: Int
    let name: String
    let description: String
    let price: Double
    let rating: Double
    let category: String
    let imageUrl: String
    
   //  Use CodingKeys to map JSON keys to properties if they differ
           
}



